module.exports = {
  baseUrl: '.',
  name: 'input',
  out: 'output.js',
  optimize: 'none',
  paths: {
    react: '../../../../build/dist/react.development',
    'react-dom': '../../../../build/dist/react-dom.development',
  },
};
